# Author - Arturs Minovs

# COVID-19 Analytics Platform

A data analytics platform for COVID-19 built with **FastAPI**, **Snowflake**, **MongoDB**, and **Streamlit**.  
The platform allows you to:
- View COVID-19 **time series** data from Snowflake
- Generate **forecasts** using ARIMA
- Leave and view **comments** stored in MongoDB
- Explore available **regions**

# Features

- FastAPI backend:
  - "/timeseries" — data per region and metric
  - "/forecast" — ARIMA forecasts
  - "/comments" — comment system
  - "/regions" — list of available regions
  - "/health" — backend health check (Snowflake + MongoDB)

- Streamlit frontend:
  - Interactive dashboard
  - Region/metric selection
  - Visualization with Plotly
  - Comment section

# Snowflake Sharing

Access to the database the Snowflake.

- Account locator: `qzbfilt-xk04134`

Example SQL to add this account to the share:

```sql
ALTER SHARE covid19_share ADD ACCOUNTS = ('qzbfilt.xk04134');


# Setup and Installation

# 1. Clone repository

git clone https://github.com/arturrw/Covid-19-Project.git

# 2. CREATE Virtual environment

python -m venv venv
source venv/bin/activate   # (Linux/Mac)
venv\Scripts\activate      # (Windows)

# 3. Install dependencies

pip install -r requirements.txt

# 4. Create .env file in root directory:

SNOWFLAKE_ACCOUNT=hu01507.eu-north-1.aws
SNOWFLAKE_USER=Your_User
SNOWFLAKE_PASSWORD=Your_Password
SNOWFLAKE_WAREHOUSE=BOOTCAMP_WH
SNOWFLAKE_DATABASE=COVID19_PROJECT
SNOWFLAKE_SCHEMA=PUBLIC
SNOWFLAKE_ROLE=ACCOUNTADMIN

MONGO_URI=mongodb+srv://<username>:<password>@covid19.7ryeip1.mongodb.net/
MONGO_DB=covid_platform

# 5. Run FastAPI Terminal:

uvicorn src.api.main:app --reload --port 8000

Backend will be available at:
http://127.0.0.1:8000
http://127.0.0.1:8000/docs

# 6. Run Streamlit:

streamlit run src/app/streamlit_app.py
http://localhost:8501/

# 7. Example of API Usage:
http://127.0.0.1:8000/
http://127.0.0.1:8000/docs
http://127.0.0.1:8000/redoc
http://127.0.0.1:8000/health
http://127.0.0.1:8000/regions

# Data
Time series data for example USA:
http://127.0.0.1:8000/timeseries?region=United%20States&metric=cases
# Forecast
http://127.0.0.1:8000/forecast?region=United%20States&metric=deaths&steps=14
# Test Time series
http://127.0.0.1:8000/timeseries-test
# Comments
http://127.0.0.1:8000/comments

# 8. TODO
 Add user authentication
 Region-specific comments
 Improved forecasting models
 Docker Compose setup for full stack