import time
from typing import Any, Callable, Dict, Tuple

class TTLCache:
    def __init__(self, ttl_seconds: int = 600):
        self.ttl = ttl_seconds
        self.store: Dict[str, Tuple[float, Any]] = {}

    def get(self, key: str):
        if key in self.store:
            ts, val = self.store[key]
            if time.time() - ts < self.ttl:
                return val
            else:
                del self.store[key]
        return None

    def set(self, key: str, value: Any):
        self.store[key] = (time.time(), value)

cache = TTLCache()
