from pymongo import MongoClient
from .config import get_settings

def get_mongo():
    s = get_settings()
    print(f"Connecting to Mongo: {s.MONGO_URI}, DB={s.MONGO_DB}")
    client = MongoClient(s.MONGO_URI)
    db = client[s.MONGO_DB]
    return db

