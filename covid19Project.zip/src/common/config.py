from pydantic import BaseModel
from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    SNOWFLAKE_ACCOUNT: str
    SNOWFLAKE_USER: str
    SNOWFLAKE_PASSWORD: str
    SNOWFLAKE_WAREHOUSE: str = "BOOTCAMP_WH"
    SNOWFLAKE_DATABASE: str = "COVID_DB"
    SNOWFLAKE_SCHEMA: str = "PUBLIC"
    SNOWFLAKE_ROLE: str = "ACCOUNTADMIN"
    MONGO_URI: str = "mongodb://localhost:27017"
    MONGO_DB: str = "covid_platform"
    CACHE_TTL_SECONDS: int = 600

    class Config:
        env_file = ".env"
        extra = "ignore"

@lru_cache
def get_settings() -> Settings:
    return Settings()
