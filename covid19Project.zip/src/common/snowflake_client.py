from typing import Any, List, Dict, Optional
import pandas as pd
import snowflake.connector
import snowflake.connector
from .config import get_settings

s = get_settings()

def get_connection():
    return snowflake.connector.connect(
        account=s.SNOWFLAKE_ACCOUNT,
        user=s.SNOWFLAKE_USER,
        password=s.SNOWFLAKE_PASSWORD,
        warehouse=s.SNOWFLAKE_WAREHOUSE,
        database=s.SNOWFLAKE_DATABASE,
        schema=s.SNOWFLAKE_SCHEMA,
        role=s.SNOWFLAKE_ROLE,
    )

def query_df(sql: str, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
    with get_connection() as conn:
        cs = conn.cursor()
        try:
            cs.execute(sql, params or {})
            rows = cs.fetchall()
            cols = [c[0] for c in cs.description]
            return pd.DataFrame(rows, columns=cols)
        finally:
            cs.close()
