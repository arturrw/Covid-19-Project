import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import os

API_URL = os.getenv("API_URL", "http://127.0.0.1:8000")

st.title("🦠 COVID-19 Analytics Platform")

# Input parameters
region = st.text_input("Region", "US-OH")
metric = st.selectbox("Metric", ["cases", "deaths"])
steps = st.slider("Forecast horizon (days)", 7, 60, 14)

# API calls
def fetch_timeseries(region, metric):
    r = requests.get(f"{API_URL}/timeseries", params={"region": region, "metric": metric})
    r.raise_for_status()
    return r.json()

def fetch_forecast(region, metric, steps):
    r = requests.get(f"{API_URL}/forecast", params={"region": region, "metric": metric, "steps": steps})
    r.raise_for_status()
    return r.json()

def fetch_comments():
    r = requests.get(f"{API_URL}/comments")
    r.raise_for_status()
    return r.json()

def add_comment(comment, user="anonymous"):
    r = requests.post(
        f"{API_URL}/comments",
        params={"user": user},
        json={"comment": comment}
    )
    return r.ok

# Time series
ts = fetch_timeseries(region, metric)

if "error" in ts:
    st.error(ts["error"])
    if "available_regions" in ts:
        st.info("Available regions: " + ", ".join(ts["available_regions"]))
else:
    df = pd.DataFrame(ts["points"])
    if not df.empty:
        fig = px.line(df, x="DATE", y="VALUE", title=f"{region} - {metric}")
        st.plotly_chart(fig)

# Forecast
fc = fetch_forecast(region, metric, steps)
if "error" in fc:
    st.error(fc["error"])
    df_fc = pd.DataFrame()
else:
    df_fc = pd.DataFrame(fc["forecast"])
    if not df_fc.empty:
        fig2 = px.line(df_fc, x="date", y="value", title=f"{steps}-day Forecast for {region}")
        st.plotly_chart(fig2)

# Comments
st.header("💬 Comments: ")

# form
with st.form("comment_form_global"):
    user = st.text_input("Your name", "Anonymous")
    comment = st.text_area("Your comment")
    submitted = st.form_submit_button("Submit")

    if submitted and comment.strip():
        ok = add_comment(comment, user)
        if ok:
            st.success("Comment added!")
            st.rerun()
        else:
            st.error("Failed to add comment")

# Comments

comments = fetch_comments()
if comments.get("comments"):
    for c in comments["comments"]:
        ts = c.get("timestamp", "")
        if isinstance(ts, str):
            try:
                ts = datetime.fromisoformat(ts.replace("Z", ""))  
                ts = ts.strftime("%Y-%m-%d %H:%M") 
            except Exception:
                pass
        st.write(f"**{c.get('user', 'anon')}** ({ts}): {c['comment']}")
else:
    st.info("No comments yet.")
