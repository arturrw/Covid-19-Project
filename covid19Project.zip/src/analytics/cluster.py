import pandas as pd
from sklearn.cluster import KMeans

def cluster_regions(df: pd.DataFrame, n_clusters: int = 5, features=None):
    if features is None:
        features = ["cases_per_100k", "deaths_per_100k", "growth_rate"]
    X = df[features].fillna(0.0).values
    kmeans = KMeans(n_clusters=n_clusters, n_init="auto", random_state=42)
    df['cluster'] = kmeans.fit_predict(X)
    return df, kmeans
