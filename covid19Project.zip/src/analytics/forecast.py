import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

def forecast_arima(series: pd.Series, steps: int = 14) -> pd.Series:
    series = series.asfreq('D').fillna(method='ffill')
    model = ARIMA(series, order=(1,1,1))
    fit = model.fit()
    fc = fit.forecast(steps=steps)
    fc.index = pd.date_range(start=series.index[-1] + pd.Timedelta(days=1), periods=steps, freq='D')
    return fc
