import traceback
import logging

from fastapi import FastAPI, Query, Body
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timedelta
import pandas as pd

from ..common import snowflake_client as sf
from ..common.mongo_client import get_mongo
from ..common.config import get_settings
from ..common.cache import cache
from ..analytics.forecast import forecast_arima

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = FastAPI(title="COVID-19 Analytics API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Root
@app.get("/")
def root():
    return {
        "message": "🚀 COVID-19 Analytics API is running!",
        "docs": "http://127.0.0.1:8000/docs",
        "redoc": "http://127.0.0.1:8000/redoc",
        "health": "http://127.0.0.1:8000/health"
    }

# Health check with Snowflake + MongoDB
@app.get("/health")
def health():
    print(" health() check")
    status = {"api": "ok"}
    try:
        df = sf.query_df("SELECT CURRENT_TIMESTAMP as ts")
        status["snowflake"] = "ok" if not df.empty else "fail"
    except Exception as e:
        status["snowflake"] = f"error: {str(e)}"

    try:
        db = get_mongo()
        db.command("ping")
        status["mongo"] = "ok"
    except Exception as e:
        status["mongo"] = f"error: {str(e)}"

    return status

@app.get("/forecast")
def get_forecast(region: str, metric: str, steps: int = 14):
    try:
        if region.startswith("US-"):
            region = "United States"

        # Region check
        sql_regions = "SELECT DISTINCT REGION FROM PUBLIC.COVID_TIMESERIES_VIEW"
        regions = sf.query_df(sql_regions)["REGION"].dropna().tolist()
        if region not in regions:
            return {
                "error": f"Region '{region}' not found.",
                "available_regions": regions
            }

        sql = f"""
            SELECT DATE, {metric} as value
            FROM PUBLIC.COVID_TIMESERIES_VIEW
            WHERE REGION = %(region)s
            ORDER BY DATE
        """
        df = sf.query_df(sql, {"region": region})
        if df.empty:
            return {"error": f"No data found for {region} / {metric}"}

        series = pd.Series(df["VALUE"].values, index=pd.to_datetime(df["DATE"]))
        fc = forecast_arima(series, steps=steps)

        forecast_points = [
            {"date": d.strftime("%Y-%m-%d"), "value": float(v)}
            for d, v in fc.items()
        ]

        return {"region": region, "metric": metric, "steps": steps, "forecast": forecast_points}

    except Exception as e:
        logger.error("Error in /forecast", exc_info=True)
        return {"error": str(e)}

@app.get("/timeseries")
def timeseries(region: str, metric: str = "cases", start: str = None, end: str = None):
    try:
        # USA Regions
        if region.startswith("US-"):
            region = "United States"

        # Region Check
        sql_regions = "SELECT DISTINCT REGION FROM PUBLIC.COVID_TIMESERIES_VIEW"
        regions = sf.query_df(sql_regions)["REGION"].dropna().tolist()
        if region not in regions:
            return {
                "error": f"Region '{region}' not found.",
                "available_regions": regions
            }

        key = f"timeseries:{region}:{metric}:{start}:{end}"
        cached = cache.get(key)
        if cached:
            return cached

        sql = f"""
            SELECT DATE, {metric} as value
            FROM PUBLIC.COVID_TIMESERIES_VIEW
            WHERE REGION = %(region)s
            { 'AND DATE >= %(start)s' if start else '' }
            { 'AND DATE <= %(end)s' if end else '' }
            ORDER BY DATE
        """
        params = {"region": region}
        if start: params["start"] = start
        if end: params["end"] = end

        df = sf.query_df(sql, params)
        payload = {"region": region, "metric": metric, "points": df.to_dict(orient="records")}
        cache.set(key, payload)
        return payload

    except Exception as e:
        logger.error("Error in /timeseries", exc_info=True)
        return {"error": str(e)}



@app.get("/timeseries-test")
def timeseries_test(region: str = "Afghanistan", metric: str = "cases"):
    return {
        "region": region,
        "metric": metric,
        "points": [
            {"DATE": "2020-01-01", "VALUE": 100},
            {"DATE": "2020-01-02", "VALUE": 120},
        ],
    }



@app.post("/comments")
def add_comment(user: str = "anonymous", body: dict = Body(...)):
    try:
        db = get_mongo()
        comment = {
            "user": user,
            "comment": body.get("comment"),
            "timestamp": datetime.utcnow()
        }
        db.comments.insert_one(comment)
        comment["_id"] = str(comment["_id"])
        comment["timestamp"] = comment["timestamp"].strftime("%Y-%m-%d %H:%M")
        return {"status": "ok", "comment": comment}
    except Exception as e:
        logger.error("Error in POST /comments", exc_info=True)
        return {"error": str(e)}


@app.get("/comments")
def get_comments():
    try:
        db = get_mongo()
        docs = list(db.comments.find().sort("timestamp", -1).limit(50))
        comments = []
        for d in docs:
            comments.append({
                "user": d.get("user", "anon"),
                "comment": d.get("comment", ""),
                "timestamp": d.get("timestamp").strftime("%Y-%m-%d %H:%M") 
                if isinstance(d.get("timestamp"), datetime) else str(d.get("timestamp"))
            })
        return {"comments": comments}
    except Exception as e:
        logger.error("Error in GET /comments", exc_info=True)
        return {"error": str(e)}
    
@app.get("/regions")
def get_regions():
    try:
        sql = "SELECT DISTINCT REGION FROM PUBLIC.COVID_TIMESERIES_VIEW ORDER BY REGION"
        df = sf.query_df(sql)
        regions = df["REGION"].dropna().tolist()
        return {"regions": regions}
    except Exception as e:
        logger.error("Error in /regions", exc_info=True)
        return {"error": str(e)}
